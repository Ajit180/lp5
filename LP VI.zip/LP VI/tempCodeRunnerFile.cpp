#include <iostream>
#include <omp.h>